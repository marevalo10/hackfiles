#!/bin/bash
#Run nikto, whatweb and nmap to all hosts and ports identified as http
#The script extract all ports from the results created by 3_preparefiles_new.sh
######################################################################################
#The base for this script was taken from a previous version provided by Carlos Marquez
#Some additions in this version were completed by Miguel Arevalo (M4rc14n0) 
######################################################################################

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

mkdir enumWEB;
echo "Selecting ports identified as http and https services in the scan"
# Grep selects only http services and not https (-v). awk extract only the third field (port). sed removes the " symbol. Sort them by number and unique ports
cat ./results/*_ipsnports_all.csv | grep http | grep -v ssl | grep -v https | awk 'BEGIN {FS = ","}; {print $3}' | sed 's/\"//g' | sort -n | uniq > ./enumWEB/httpports.txt
# Selects https
cat ./results/*_ipsnports_all.csv | grep 'https\|ssl' | awk 'BEGIN {FS = ","}; {print $3}' | sed 's/\"//g' | sort -n | uniq > ./enumWEB/httpsports.txt

echo "####################################################################"
echo "Checking HTTP servers on identified ports using Whatweb and Nikto..."
for port in $(cat ./enumWEB/httpports.txt); do
    filename=$port"_all_TCP.ips"
    numips=$(cat ./results/$filename | wc -l)
    echo "Running Whatweb and Nikto for all IP's ${RED}($numips)${NC} in ${GREEN} $filename ${NC}"
    for i in $(cat ./results/$filename); do 
        echo "Testing $i port $port with WhatWeb"; 
        whatweb -a 3 $i | tee enumWEB/whatweb$i-$port.txt ;
        nikto -host $i -p $port -o enumWEB/nikto$i-$port.csv -maxtime 300
    done
done

echo "####################################################################"
echo "Checking HTTPS servers on identified ports using Whatweb and Nikto..."
for port in $(cat ./enumWEB/httpsports.txt); do
    filename=$port"_all_TCP.ips"
    numips=$(cat ./results/$filename | wc-l)
    echo "Running Whatweb and Nikto for all IP's ${RED}($numips)${NC} in ${GREEN} $filename ${NC}"
    for i in $(cat ./results/$filename); do 
        echo "Testing $i port $port with WhatWeb"; 
        whatweb -a 3 --url-prefix https://  $i:$port | tee enumWEB/whatweb$i-$port.txt
        nikto -host $i -p $port -o enumWEB/nikto$i-$port.csv -maxtime 300
    done
done
echo "####################################################################"

# Test SSL certificates
echo "Checking TLS connections on HTTPS using nmap..."
for port in $(cat ./enumWEB/httpsports.txt); do
    filename=$port"_all_TCP.ips"
    nmap -sV --script=ssl-enum-ciphers,ssl-ccs-injection.nse,ssl-dh-params.nse,ssl-date.nse,ssl-dh-params.nse,ssl-heartbleed.nse,ssl-known-key.nse,ssl-poodle.nse,sslv2-drown.nse,sslv2.nse -p $port -iL ./results/$filename -oA enumWEB/nmap_sslenum_$port
done
echo "Checking TLS connections on SQL Servers using nmap..."
nmap -sV --script=ssl-enum-ciphers -p 1433 -iL ./results/1433_all_TCP.ips -oA enumWEB/nmap_sslenum_1433
echo "All checks has being completed"
echo "####################################################################"

