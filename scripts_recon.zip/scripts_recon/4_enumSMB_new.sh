#!/bin/bash
#Run enum4linux and rpcdump on all hosts identified with port 445 open
#Takes the file ./results/445_all_TCP.ips created by 3_preparefiles_new as input
#Run nmap with rdpenum script for all host with port 3389 open
#requires enum4linux instaled and available in the running path
######################################################################################
#The base for this script was taken from a previous version provided by Carlos Marquez
#Some additions in this version were completed by Miguel Arevalo (M4rc14n0) 
######################################################################################

mkdir enumSMB;
file=445_all_TCP.ips
for i in $(cat ./results/$file); do 
    echo "********************************************************"
    echo "Checkin IP: "$i; 
    enum4linux $i | tee enumSMB/$i_enum4.txt 
    echo "********************************************************"
    echo "Checkin IP: "$i" using rpcdump"; 
    python3 /usr/share/doc/python3-impacket/examples/rpcdump.py $i | tee enumSMB/$i_rpcdump.txt;
    echo "Scan Completed for $i IPs "; 
done

#Run RDP enumeration using NMAP port hosts in file 3389.ips
#nmap scripts: rdp-enum-encryption,rdp-ntlm-info,rdp-vuln-ms12-020
mkdir enumRDP;  
echo "********************************************************"
echo "Checking RDP for port 3389"; 
sudo nmap -Pn -p 3389 -Pn --script=rdp-enum-encryption,rdp-ntlm-info,rdp-vuln-ms12-020 -oA enumRDP/enumRDPALL --open -vvv -n  -iL ./results/3389_all_TCP.ips

#Run SMB enumeration (nmap scripts) using NMAP port hosts in file $file
echo "********************************************************"
echo "Checking SMB vulnerabilities port 445, 139 and 135"; 
sudo nmap -Pn -n -p445,139,135 -vvvv --script=smb-os-discovery,smb-enum-shares,smb-enum-users,smb-enum-sessions,smb-system-info,smb-brute,smb-vuln-ms17-010 -oA enumSMB/nmap-SMB -iL ./results/$file --open 
echo "********************************************************"
echo "Checking SMB2 on port 445"; 
sudo nmap -Pn -n -vvvv --script=smb-double-pulsar-backdoor.nse,smb-vuln-conficker.nse,smb-vuln-cve2009-3103.nse,smb-vuln-cve-2017-7494.nse,smb-vuln-ms06-025.nse,smb-vuln-ms07-029.nse,smb-vuln-ms08-067.nse,smb-vuln-ms10-054.nse,smb-vuln-ms10-061.nse,smb-vuln-ms17-010.nse,smb-vuln-regsvc-dos.nse -Pn -p445 -oA enumSMB/nmap-SMB2 -iL ./results/$file

sudo chown -R marevalo:marevalo enumRDP/*
sudo chown -R marevalo:marevalo enumSMB/*