#!/bin/bash
#Run nikto and whatweb to hosts in files 80.ips, 443.ips, 8080.ips

mkdir enumWEB;
echo "Checking webservers on port 80, 8080 and 443 using Whatweb and Nikto..."
for i in $(cat ./results/80_all_TCP.ips); do echo "Testing $i port 80 with WhatWeb" ; whatweb -a 3 $i | tee enumWEB/whatweb$i-80.txt ;done
for i in $(cat ./results/8080_all_TCP.ips); do echo "Testing $i port 8080 with WhatWeb" ; whatweb -a 3 $i:8080 | tee enumWEB/whatweb$i-8080.txt ;done
for i in $(cat ./results/443_all_TCP.ips); do echo "Testing $i port 443 with WhatWeb" ; whatweb -a 3 --url-prefix https://  $i:443 | tee enumWEB/whatweb$i-443.txt ;done
for i in $(cat ./results/80_all_TCP.ips); do echo "Testing $i port 80 with Nikto" ; nikto -host $i -p 80  -o enumWEB/nikto$i-80.csv -maxtime 300 ;done
for i in $(cat ./results/443_all_TCP.ips); do echo "Testing $i port 443 with Nikto" ; nikto -host $i -p 443  -o enumWEB/nikto$i-443.csv -maxtime 300 ;done
for i in $(cat ./results/8080_all_TCP.ips); do echo "Testing $i port 8080 with Nikto" ; nikto -host $i -p 8080  -o enumWEB/nikto$i-8080.csv -maxtime 300 ;done

# Test SSL certificates
echo "Checking TLS connections on port 443, 1433 and 3389 using nmap..."
nmap -sV --script=ssl-enum-ciphers -p 443 -iL ./results/443_all_TCP.ips -oA enumWEB/nmap_sslenum_443
nmap -sV --script=ssl-enum-ciphers -p 1433 -iL ./results/1433_all_TCP.ips -oA enumWEB/nmap_sslenum_1433
nmap -sV --script=ssl-enum-ciphers -p 3389 -iL ./results/3389_all_TCP.ips -oA enumWEB/nmap_sslenum_3389

# Add additional wen ports identified in the reconnaissance (based on the ports detected as webports) 