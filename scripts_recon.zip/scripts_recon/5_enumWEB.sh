#!/bin/bash
#Run nikto and whatweb to hosts in files 80.ips, 443.ips, 8080.ips

mkdir enumWEB;

for i in $(cat ./results/80_all_TCP.ips); do echo "Testing $i port 80 with WhatWeb" ; whatweb -a 3 $i | tee enumWEB/whatweb$i-80.txt ;done
for i in $(cat ./results/8080_all_TCP.ips); do echo "Testing $i port 8080 with WhatWeb" ; whatweb -a 3 $i:8080 | tee enumWEB/whatweb$i-8080.txt ;done
for i in $(cat ./results/443_all_TCP.ips); do echo "Testing $i port 443 with WhatWeb" ; whatweb -a 3 --url-prefix https://  $i:443 | tee enumWEB/whatweb$i-443.txt ;done
for i in $(cat ./results/80_all_TCP.ips); do echo "Testing $i port 80 with Nikto" ; nikto -host $i -p 80  -o enumWEB/nikto$i-80.csv -maxtime 300 ;done
for i in $(cat ./results/443_all_TCP.ips); do echo "Testing $i port 443 with Nikto" ; nikto -host $i -p 443  -o enumWEB/nikto$i-443.csv -maxtime 300 ;done
for i in $(cat ./results/8080_all_TCP.ips); do echo "Testing $i port 8080 with Nikto" ; nikto -host $i -p 8080  -o enumWEB/nikto$i-8080.csv -maxtime 300 ;done
