#!/bin/bash
#Must be run in the path where resumenmap.sh output was stored

#create a file with identified open ports by line
mkdir focused; 
for((i=1;i<=` cat ips.txt.resumenmap.openports.csv | wc -l` ;i++)); do awk FNR==$i ips.txt.resumenmap.openports.csv| grep -o  -E "\b[0-9]{1,5}/open"  | sed 's/\/open//g' | awk -vORS=, '{ print  }'  > focused/ports.line.$i    ;  done

#Runing a focused VULNERABILITY SCAN (nmap scripts) to all hosts with specific identified open ports by resumenmap.sh
j=0; for i in $(cat ips.txt.resumenmap.hosts.csv); do echo "Scaning $i in line $j"; echo "incrementing $((j++))"; nmap $i -p `cat focused/ports.line.$((j++))` -R  -PE -PP -Pn --source-port 53 --traceroute --reason -sV -A -sC -O --script=default,auth,vuln,version --open -vvv -oA focused/.$j.vuln-scan.$i --min-rate 500 --max-rate 700 --privileged ; done
