#!/bin/bash
#Run enum4linux on all hosts in file 445_all_TCP.ips
#requires enum4linux instaled and available in the running path
mkdir enumSMB;
file=445_all_TCP.ips
for i in $(cat ./results/$file); do echo $i; 
    enum4linux $i | tee enumSMB/$i_enum4.txt 
    python3 /usr/share/doc/python3-impacket/examples/rpcdump.py $i | tee enumSMB/$i_rpcdump.txt;
done

#Run RDP enumeration using NMAP port hosts in file 3389.ips
mkdir enumRDP;  
#Antes hacia esto, pero el resultado de cada ciclo es el mismo. NMAP hace el escaneo de todas las IP's en el archivo
#for i in $(cat 3389.ips); do echo $i; nmap -p 3389 -Pn -iL 3389.ips --script rdp-enum-encryption $i -oA enumRDP/enumRDP$i --open -vvv -n;done 
nmap -p 3389 -Pn -iL ./results/3389_all_TCP.ips --script rdp-enum-encryption -oA enumRDP/enumRDPALL --open -vvv -n; 

#Run SMB enumeration (nmap scripts) using NMAP port hosts in file $file
#for i in $(cat ./results/$file); 
#do 
#    echo $i; 
#    nmap -p445,139,135 -vvvv --script=smb-os-discovery,smb-enum-shares,smb-enum-users,smb-enum-sessions,smb-system-info,smb-brute,smb-vuln-ms17-010 -oA enumSMB/$i_nmap-SMB $i --open; 
#    nmap -vvvv --script=smb-vuln-conficker.nse,smb-vuln-cve2009-3103.nse,smb-vuln-cve-2017-7494.nse,smb-vuln-ms06-025.nse,smb-vuln-ms07-029.nse,smb-vuln-ms08-067.nse,smb-vuln-ms10-054.nse,smb-vuln-ms10-061.nse,smb-vuln-ms17-010.nse,smb-vuln-regsvc-dos.nse -Pn -p445 -oA enumSMB/$i_nmap-SMB2 $i
#done
# Before it was ip by ip, now I left all in the same call
nmap -p445,139,135 -vvvv --script=smb-os-discovery,smb-enum-shares,smb-enum-users,smb-enum-sessions,smb-system-info,smb-brute,smb-vuln-ms17-010 -oA enumSMB/nmap-SMB -iL ./results/$file --open; 
nmap -vvvv --script=smb-vuln-conficker.nse,smb-vuln-cve2009-3103.nse,smb-vuln-cve-2017-7494.nse,smb-vuln-ms06-025.nse,smb-vuln-ms07-029.nse,smb-vuln-ms08-067.nse,smb-vuln-ms10-054.nse,smb-vuln-ms10-061.nse,smb-vuln-ms17-010.nse,smb-vuln-regsvc-dos.nse -Pn -p445 -oA enumSMB/nmap-SMB2 -iL ./results/$file

sudo chown -R marevalo:marevalo enumRDP/*
sudo chown -R marevalo:marevalo enumSMB/*