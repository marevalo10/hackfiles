#!/bin/bash
#Run enum4linux on all hosts in 445.ips
#requires enum4linux instaled and available in the running path
mkdir enumSSH;
for ipadd in $(cat ./results/22_all_TCP.ips); do echo $ipadd; ssh -o "StrictHostKeyChecking no" -vN $ipadd 2>&1 | grep "remote software version" | tee enumSSH/enum$ipadd.txt ;done
